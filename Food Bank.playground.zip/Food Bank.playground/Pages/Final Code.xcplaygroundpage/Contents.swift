//: [Previous](@previous)
import Foundation

import UIKit
import PlaygroundSupport


var cfURL = Bundle.main.url(forResource: "PTSans-Bold", withExtension: "ttf")! as CFURL
CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)

cfURL = Bundle.main.url(forResource: "PTSans-BoldItalic", withExtension: "ttf")! as CFURL
CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)

cfURL = Bundle.main.url(forResource: "PTSans-Italic", withExtension: "ttf")! as CFURL
CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)

cfURL = Bundle.main.url(forResource: "PTSans-Regular", withExtension: "ttf")! as CFURL
CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)


class MyViewController0 : UIViewController {
    
    let button = UIButton()
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        
        let appName = UILabel()
        appName.frame = CGRect(x: 500, y: 100, width: 500, height: 100)
        appName.text = "Food Bank"
        appName.textColor = .black
        let AppNameFont = UIFont (name: "PTSans-Bold", size: 80)
        appName.font = AppNameFont
        view.addSubview(appName)
        
        let title1 = UILabel()
        title1.frame = CGRect(x: 100, y: 100, width: 1200, height: 400)
        title1.numberOfLines = 0
        title1.text = "May 2020. Brazil, one of the most unnequal contries in the planet, has been severely affected by the COVID-19 outbreak. The poor and vulnerable ones, who already suffered before the coronavirus crisis, are now feeling the pain of an inneficient social security system. Without proper government help, many Brazilians have to leave their houses and work."
        title1.textColor = .black
        let title1Font = UIFont(name: "PT Sans", size: 30)
        title1.font = title1Font
        view.addSubview(title1)
        
        let title2 = UILabel()
        title2.frame = CGRect(x: 100, y: 400, width: 1200, height: 85)
        title2.numberOfLines = 0
        title2.text = "They are aware that going out means contamination. But considering that staying at home means starving to death, they choose the first, instead of the latter."
        title2.textColor = .black
        let title2Font = UIFont(name: "PTSans-Bold", size: 30)
        title2.font = title2Font
        view.addSubview(title2)
        
        let title3 = UILabel()
        title3.frame = CGRect(x: 100, y: 480, width: 1200, height: 300)
        title3.numberOfLines = 0
        title3.text = "This playground was created in honor of those who need it the most. It is based on solidarity, compassion and human care. It takes into consideration the fact that 1/3 of all the food produced globally is wasted every year.  And also that 40% of this waste takes place in sales facilities like supermarkets and stores, mainly because the food was not sold (FAO). The idea is that, instead of throwing away, food traders can announce their unsold surpluses here, so that the ones who are in need can have access to this basic human right that eating is."
        title3.textColor = .black
        let title3Font = UIFont(name: "PT Sans", size: 30)
        title3.font = title3Font
        view.addSubview(title3)
        
        let title4 = UILabel()
        title4.frame = CGRect(x: 100, y: 750, width: 1200, height: 100)
        title4.numberOfLines = 0
        title4.text = "“Everyone has the right to life.” (Article 3, Universal Declaration of Human Rights)"
        title4.textColor = .black
        let title4Font = UIFont(name: "PTSans-Bold", size: 30)
        title4.font = title4Font
        view.addSubview(title4)
        
        let title5 = UILabel()
        title5.frame = CGRect(x: 300, y: 850, width: 800, height: 100)
        title5.numberOfLines = 0
        title5.text = "To begin, simply click anywhere on the screen."
        title5.textColor = .black
        let title5Font = UIFont(name: "PT Sans", size: 40)
        title5.font = title5Font
        view.addSubview(title5)
        
        
        //let PreparedMealImage = UIImage(named: "Ingredientes.jpg")
        let PreparedMealButton = UIButton()
        PreparedMealButton.frame = CGRect(x: 0, y: 0, width: 1000, height: 1000)
       // PreparedMealButton.setImage(PreparedMealImage, for: .normal)
        PreparedMealButton.imageView?.layer.cornerRadius = 10
        PreparedMealButton.addTarget(nil, action: #selector(touchIngredient), for: .touchUpInside)
        view.addSubview(PreparedMealButton)
        //
        
        self.view = view
        
    }
    
    @objc func touchIngredient() {
        navigationController?.pushViewController(MyViewController(), animated: true)
        
    }
   
    
}
class MyViewController : UIViewController {
    
    let button = UIButton()
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        
        let appName = UILabel()
        appName.frame = CGRect(x: 42, y: 62, width: 361, height: 68)
        appName.text = "Food Bank"
        appName.textColor = .black
        let AppNameFont = UIFont (name: "PT Sans", size: 50)
        appName.font = AppNameFont
        view.addSubview(appName)
        
        let mainQuestion = UILabel()
        mainQuestion.frame = CGRect(x: 308, y: 270, width: 800, height: 95)
        mainQuestion.text = "What are you looking for?"
        mainQuestion.textColor = .black
        let QuestionFont = UIFont(name: "PTSans-Bold", size: 70)
        mainQuestion.font = QuestionFont
        view.addSubview(mainQuestion)
        
        
        let PreparedMealImage = UIImage(named: "Ingredientes.jpg")
        let PreparedMealButton = UIButton()
        PreparedMealButton.frame = CGRect(x: 136, y: 441, width: 473, height: 426)
        PreparedMealButton.setImage(PreparedMealImage, for: .normal)
        PreparedMealButton.imageView?.layer.cornerRadius = 10
        PreparedMealButton.addTarget(nil, action: #selector(touchIngredient), for: .touchUpInside)
        view.addSubview(PreparedMealButton)
        let PreparedMealLabel = UILabel()
        PreparedMealLabel.frame = CGRect(x: 244, y: 876, width: 242, height: 64)
        PreparedMealLabel.text = "Ingredients"
        PreparedMealLabel.textColor = .black
        let ButtonFont = UIFont (name: "PTSans-Bold", size: 45)
        PreparedMealLabel.font = ButtonFont
        view.addSubview(PreparedMealLabel)
        
        let IngredientImage = UIImage(named: "Macarronada.jpg")
        let IngredientButton = UIButton()
        IngredientButton.frame = CGRect(x: 767, y: 441, width: 473, height: 426)
        IngredientButton.setImage(IngredientImage, for: .normal)
        IngredientButton.imageView?.layer.cornerRadius = 10
        IngredientButton.addTarget(nil, action: #selector(touchPreparedMeal), for: .touchUpInside)
        view.addSubview(IngredientButton)
        let IngredientLabel = UILabel()
        IngredientLabel.frame = CGRect(x: 883, y: 876, width: 300, height: 55)
        IngredientLabel.text = "Prepared meal"
        let fonteDeIngredientes = UIFont(name: "PTSans-Bold", size: 45)
        IngredientLabel.font = fonteDeIngredientes
        view.addSubview(IngredientLabel)
        
        self.view = view
        
    }
    
    @objc func touchIngredient() {
        navigationController?.pushViewController(MyViewController2(), animated: true)
        
    }
    @objc func touchPreparedMeal(){
        navigationController?.pushViewController(MyViewController8(), animated: true)
    }
    
}

class MyViewController8 : UIViewController {
    
    
    override func viewDidLoad() {
        let view = UIView()
        view.backgroundColor = .white
        
        
        let appName = UILabel()
        appName.frame = CGRect(x: 42, y: 62, width: 361, height: 68)
        appName.text = "Food Bank"
        appName.textColor = .black
        let AppNameFont = UIFont (name: "PT Sans", size: 50)
        appName.font = AppNameFont
        view.addSubview(appName)
        
        let AvailabilityCaller = UILabel()
        AvailabilityCaller.frame = CGRect(x: 42, y: 197, width: 582, height: 100)
        AvailabilityCaller.text = "Oh, no..."
        AvailabilityCaller.textColor = .black
        let CallerFont = UIFont (name: "PTSans-Bold", size: 70)
        AvailabilityCaller.font = CallerFont
        view.addSubview(AvailabilityCaller)
        
        let AvailabilityDescription = UILabel()
        AvailabilityDescription.frame = CGRect(x: 42, y: 297, width: 1086, height: 51)
        AvailabilityDescription.text = "There are no prepared meals available near you today."
        AvailabilityDescription.textColor = .black
        let DescriptionFont = UIFont (name: "PT Sans", size: 35)
        AvailabilityDescription.font = DescriptionFont
        view.addSubview(AvailabilityDescription)
        
        let mainQuestion = UILabel()
        mainQuestion.frame = CGRect(x: 150, y: 630, width: 1100, height: 53)
        mainQuestion.text = "But why don't you have a look on the ingredients? :D"
        mainQuestion.textColor = .black
        let QuestionFont = UIFont (name: "PTSans-Bold", size: 45)
        mainQuestion.font = QuestionFont
        view.addSubview(mainQuestion)
        
        
        self.view = view
        
    }
    
}


class MyViewController2 : UIViewController {
    
    let button = UIButton()
    
    override func viewDidLoad() {
        let view = UIView()
        view.backgroundColor = .white
        
        
        let appName = UILabel()
        appName.frame = CGRect(x: 42, y: 62, width: 361, height: 68)
        appName.text = "Food Bank"
        appName.textColor = .black
        let AppNameFont = UIFont (name: "PT Sans", size: 50)
        appName.font = AppNameFont
        view.addSubview(appName)
        
        let AvailabilityCaller = UILabel()
        AvailabilityCaller.frame = CGRect(x: 42, y: 197, width: 582, height: 100)
        AvailabilityCaller.text = "Right next to you!"
        AvailabilityCaller.textColor = .black
        let CallerFont = UIFont (name: "PTSans-Bold", size: 70)
        AvailabilityCaller.font = CallerFont
        view.addSubview(AvailabilityCaller)
        
        let AvailabilityDescription = UILabel()
        AvailabilityDescription.frame = CGRect(x: 42, y: 297, width: 1086, height: 51)
        AvailabilityDescription.text = "These are the ingredients available near you today."
        AvailabilityDescription.textColor = .black
        let DescriptionFont = UIFont (name: "PT Sans", size: 35)
        AvailabilityDescription.font = DescriptionFont
        view.addSubview(AvailabilityDescription)
        
        let mainQuestion = UILabel()
        mainQuestion.frame = CGRect(x: 391, y: 459, width: 543, height: 53)
        mainQuestion.text = "Select a category for details"
        mainQuestion.textColor = .black
        let QuestionFont = UIFont (name: "PTSans-Bold", size: 45)
        mainQuestion.font = QuestionFont
        view.addSubview(mainQuestion)
        
        
        let FruitImage = UIImage(named: "Frutas.jpg")
        let FruitButton = UIButton()
        FruitButton.frame = CGRect(x: 512, y: 552, width: 341, height: 273)
        FruitButton.setImage(FruitImage, for: .normal)
        FruitButton.imageView?.layer.cornerRadius = 10
        FruitButton.addTarget(nil, action: #selector(touchFruit), for: .touchUpInside)
        view.addSubview(FruitButton)
        let FruitLabel = UILabel()
        FruitLabel.frame = CGRect(x: 624, y: 844, width: 117, height: 37)
        FruitLabel.text = "Fruits"
        FruitLabel.textColor = .black
        let FruitFont = UIFont(name: "PTSans-Bold", size: 40)
        FruitLabel.font = FruitFont
        view.addSubview(FruitLabel)
        
        let VegetableImage = UIImage(named: "Legumes.jpg")
        let VegetableButton = UIButton()
        VegetableButton.frame = CGRect(x: 109, y: 559, width: 342, height: 266)
        VegetableButton.setImage(VegetableImage, for: .normal)
        VegetableButton.imageView?.layer.cornerRadius = 10
        VegetableButton.addTarget(nil, action: #selector(touchVegetable), for: .touchUpInside)
        view.addSubview(VegetableButton)
        let VegetableLabel = UILabel()
        VegetableLabel.frame = CGRect(x: 184, y: 833, width: 191, height: 48)
        VegetableLabel.text = "Vegetables"
        VegetableLabel.textColor = .black
        let VegetableFont = UIFont(name: "PTSans-Bold", size: 40)
        VegetableLabel.font = VegetableFont
        view.addSubview(VegetableLabel)
        
        
        let ProteinImage = UIImage(named: "proteinas.jpg")
        let ProteinButton = UIButton()
        ProteinButton.frame = CGRect(x: 914, y: 552, width: 342, height: 273)
        ProteinButton.setImage(ProteinImage, for: .normal)
        ProteinButton.imageView?.layer.cornerRadius = 10
        ProteinButton.addTarget(nil, action: #selector(touchProtein), for: .touchUpInside)
        view.addSubview(ProteinButton)
        let ProteinLabel = UILabel()
        ProteinLabel.frame = CGRect(x: 1021, y: 844, width: 145, height: 42)
        ProteinLabel.text = "Proteins"
        let ProteinFont = UIFont(name: "PTSans-Bold", size: 40)
        ProteinLabel.font = ProteinFont
        view.addSubview(ProteinLabel)
        
        self.view = view
        
    }
    
    @objc func touchVegetable(){
        navigationController?.pushViewController(MyViewController3(), animated: true)
    }
    
    @objc func touchFruit(){
        navigationController?.pushViewController(MyViewController5(), animated: true)
    }
    
    @objc func touchProtein(){
        navigationController?.pushViewController(MyViewController7(), animated: true)
    }
}


class CatalogCell: UICollectionViewCell{
    
    public let illustration: UIImageView  = UIImageView(frame: CGRect(x: 0, y: 0, width: 337.7, height: 91.67))
    public let title: UILabel = UILabel(frame: CGRect(x: 20, y: 19, width: 230, height: 55.43))
    
    
    public override init(frame: CGRect){
        super.init(frame:frame)
        self.backgroundView = illustration
        title.font = UIFont(name: "PTSans-Bold", size: 40)
        title.textColor = .white
        self.layer.cornerRadius = 10
        self.layer.masksToBounds = true
        self.addSubview(title)
        
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class ItemStructure {
    let itemName: String
    let itemPhoto: UIImage?
    let itemDescription: String
    let itemAvailability: [Lugar]
    
    init(nome: String, foto: UIImage?, descricao: String, lugares: [Lugar]){
        itemName = nome
        itemPhoto = foto
        itemDescription = descricao
        itemAvailability = lugares
    }
}

class Lugar{
    let placeName: String
    let withdrawalTime: String
    let distance: String
    
    init(nome: String, hora: String, dist: String){
        placeName = nome
        withdrawalTime = hora
        distance = dist
    }
}


class MyViewController3 : UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    let placeExamples = [Lugar(nome: "Quitandaria", hora: "19:00", dist: "a 250m"), Lugar(nome: "Bompreço", hora: "21:00", dist: "a 2.5km"), Lugar(nome: "Mercado de Zé", hora: "15:30", dist: "a 50m")]
    
    var vegetableList:[ItemStructure] = []
    
    
    override func viewDidLoad() {
        
        let appName = UILabel()
        appName.frame = CGRect(x: 42, y: 62, width: 361, height: 68)
        appName.text = "Food Bank"
        appName.textColor = .black
        let AppNameFont = UIFont (name: "PT Sans", size: 50)
        appName.font = AppNameFont
        view.addSubview(appName)
        
        let catalogTitle = UILabel()
        catalogTitle.frame = CGRect(x: 42, y: 193, width: 780, height: 88)
        catalogTitle.text = "Available food catalog"
        catalogTitle.textColor = .black
        let catalogFont = UIFont (name: "PTSans-Bold", size: 65)
        catalogTitle.font = catalogFont
        view.addSubview(catalogTitle)
        
        let catalogDescription = UILabel()
        catalogDescription.frame = CGRect(x: 45, y: 276, width: 316, height: 47)
        catalogDescription.text = "Category: vegetables"
        catalogDescription.textColor = .black
        let catalogDescriptionFont = UIFont (name: "PT Sans", size: 35)
        catalogDescription.font = catalogDescriptionFont
        view.addSubview(catalogDescription)
        
        let mainQuestion = UILabel()
        mainQuestion.frame = CGRect(x: 401, y: 452, width: 548, height: 60)
        mainQuestion.text = "Select any option for details"
        mainQuestion.textColor = .black
        let QuestionFont = UIFont (name: "PTSans-Bold", size: 45)
        mainQuestion.font = QuestionFont
        view.addSubview(mainQuestion)
        
        vegetableList = [ItemStructure(nome: "Coriander", foto: UIImage(named: "coentro-5.jpg"), descricao: "Coriander is a herbal plant widely used in cooking and alternative medicine. It brings great benefits for helth, such as reducing the risk of cardiovascular diseases, degenerative diseases and cancer due to its antioxidant properties.", lugares: placeExamples), ItemStructure(nome: "Eggplant", foto: UIImage(named: "sh_beringela_432696973.jpg"), descricao: "A serving of eggplant can provide at least 5% of a person’s daily requirement of fiber, copper, manganese, B-6, and thiamine. It also contains other vitamins and minerals. In addition, it helps the body eliminate free radicals — unstable molecules that can damage cells if they accumulate in large amounts. Foods that contain antioxidants may help prevent a range of diseases  [Medicalnewstoday.com].", lugares: placeExamples), ItemStructure(nome: "Red onion", foto: UIImage(named: "cebola-roxa-768x307-b88dde90.jpg"), descricao: "Red onions are capable of bossting our immune system. It is also a rich source of vitamin K, B6, and C, but at the same time, the phytochemicals act as a stimulant to vitamin C within the body. Fiber from red onion helps in functioning of the digestive tract, and it helps prevent constipation [Vegetablefacts.net].", lugares: placeExamples), ItemStructure(nome: "Carrot", foto: UIImage(named: "beneficios-da-cenoura_14186_l.jpg"), descricao: "Carrots are a particularly good source of beta carotene, fiber, vitamin K1, potassium, and antioxidants. They’re a weight-loss-friendly food and have been linked to lower cholesterol levels and improved eye health [Healthline.com].", lugares: placeExamples), ItemStructure(nome: "Broccoli", foto: UIImage(named: "broccoli.jpg"), descricao: "Broccoli is reputed to benefit digestion, the cardiovascular system and the immune system, and to have anti-inflammatory and even cancer-preventing properties. Plus, broccoli is low in sodium and calories, at about 31 calories per serving. It's also a fat-free vegetable [Livescience.com].", lugares: placeExamples), ItemStructure(nome: "Pumpkin", foto: UIImage(named: "pumpkin.jpg"), descricao: "Although commonly seen as a vegetable, pumpkins are scientifically fruits. Besides helping digestion, they also contribute to regulate blood pressure, improve immunity, fight diabetes, and decrease cancer risk.", lugares: placeExamples), ItemStructure(nome: "Corn", foto: UIImage(named: "Corn.jpg"), descricao: "As a whole grain, corn is in a health-protective food category. Numerous studies have tied whole grain consumption to a lower risk of heart disease, stroke, cancer, type 2 diabetes, and obesity [Health.com].", lugares: placeExamples), ItemStructure(nome: "Bell pepper", foto: UIImage(named: "Bellpep.jpg"), descricao: "Also called sweet peppers or capsicums, bell peppers can be eaten either raw or cooked. They are low in calories and exceptionally rich in vitamin C and other antioxidants, making them an excellent addition to a healthy diet.", lugares: placeExamples), ItemStructure(nome: "Radish", foto: UIImage(named: "rad.jpg"), descricao: "With their crunchy texture and slightly peppery taste, radishes are a delicious addition to salads. They're chock-full of fiber, vitamin C and antioxidants, offering both nutrition and flavor. Compared to other root veggies, they have fewer calories and carbs. A stronger immune system, weight loss and better digestion are just a few of the many health benefits of radishes [Livestrong.com].", lugares: placeExamples)]
        
        
        view.backgroundColor = .white
        
        let myLayout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        myLayout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        myLayout.itemSize = CGSize(width: 337.7, height: 91.67)
        myLayout.minimumLineSpacing = 50
        
        
        let myCollectionView = UICollectionView(frame: CGRect(x: 86, y: 552, width: 1193, height: 372), collectionViewLayout: myLayout)
        
        myCollectionView.register(CatalogCell.self, forCellWithReuseIdentifier: "id")
        myCollectionView.backgroundColor = .white
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
        
        view.addSubview(myCollectionView)
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return vegetableList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let myCell = collectionView.dequeueReusableCell(withReuseIdentifier: "id", for: indexPath) as? CatalogCell
        
        myCell?.illustration.image = vegetableList[indexPath.item].itemPhoto
        myCell?.title.text = vegetableList[indexPath.item].itemName
        return myCell!
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let mvc4 = MyViewController4(vegetal: vegetableList[indexPath.item])
        show(mvc4, sender: nil)
        
    }
    
}

class MyViewController4: UIViewController{
    
    var specificItem: ItemStructure
    
    init(vegetal: ItemStructure) {
        
        specificItem = vegetal
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {

        let pop_up = UIView()
        pop_up.backgroundColor = #colorLiteral(red: 0.02745098039, green: 0.1176470588, blue: 0.1333333333, alpha: 1)
        
        let popUpImage = UIImageView(frame: CGRect(x: 0, y: 20, width: 650, height: 1200))
        let image = self.specificItem.itemPhoto
        popUpImage.image = image
        pop_up.addSubview(popUpImage)
        
        let backgroundSmoother = UIView()
        backgroundSmoother.frame = CGRect(x: 0, y: 41, width: 650, height: 1200)
        backgroundSmoother.backgroundColor = .black
        backgroundSmoother.alpha = 0.55
        pop_up.addSubview(backgroundSmoother)
        
        let popUpName = UILabel(frame: CGRect(x: 17.68, y: 71, width: 500, height: 84.3))
        popUpName.font = UIFont(name: "PTSans-Bold", size: 70)
        popUpName.textColor = .white
        popUpName.text = self.specificItem.itemName
        pop_up.addSubview(popUpName)
        
        let popUpAnnounce = UILabel(frame: CGRect(x: 57, y: 211, width: 394, height: 54))
        popUpAnnounce.text = "Available at:"
        popUpAnnounce.textColor = .white
        popUpAnnounce.font = UIFont(name: "PTSans-Bold", size: 45)
        pop_up.addSubview(popUpAnnounce)
        
        let place1 = UILabel(frame: CGRect(x: 57, y: 320, width: 550, height: 90))
        place1.backgroundColor = .white
        place1.text = "  John's Market"
        place1.textColor = .black
        place1.font = UIFont(name: "PTSans-Bold", size: 45)
        pop_up.addSubview(place1)
        let place1Distance = UILabel(frame: CGRect(x: 530, y: 335, width: 150, height: 50))
        place1Distance.text = "250m"
        place1Distance.textColor = .black
        place1Distance.font = UIFont(name: "PTSans-Italic", size: 25)
        pop_up.addSubview(place1Distance)
        let place1PickupTime = UILabel(frame: CGRect(x: 57, y: 390, width: 550, height: 80))
        place1PickupTime.text = "   Withdraw until 17:00"
        place1PickupTime.textColor = .black
        place1PickupTime.backgroundColor = .white
        place1PickupTime.font = UIFont(name: "PT Sans", size: 28)
        pop_up.addSubview(place1PickupTime)
        
        let place2 = UILabel(frame: CGRect(x: 57, y: 500, width: 550, height: 90))
        place2.backgroundColor = .white
        place2.text = "  Wallmart"
        place2.textColor = .black
        place2.font = UIFont(name: "PTSans-Bold", size: 45)
        pop_up.addSubview(place2)
        let place2Distance = UILabel(frame: CGRect(x: 530, y: 515, width: 150, height: 50))
        place2Distance.text = "700m"
        place2Distance.textColor = .black
        place2Distance.font = UIFont(name: "PTSans-Italic", size: 25)
        pop_up.addSubview(place2Distance)
        let place2PickupTime = UILabel(frame: CGRect(x: 57, y: 570, width: 550, height: 80))
        place2PickupTime.text = "   Withdraw until 21:00"
        place2PickupTime.textColor = .black
        place2PickupTime.backgroundColor = .white
        place2PickupTime.font = UIFont(name: "PT Sans", size: 28)
        pop_up.addSubview(place2PickupTime)
        
        let place3 = UILabel(frame: CGRect(x: 57, y: 680, width: 550, height: 90))
        place3.backgroundColor = .white
        place3.text = "  Costco"
        place3.textColor = .black
        place3.font = UIFont(name: "PTSans-Bold", size: 45)
        pop_up.addSubview(place3)
        let place3Distance = UILabel(frame: CGRect(x: 530, y: 695, width: 150, height: 50))
        place3Distance.text = "500m"
        place3Distance.textColor = .black
        place3Distance.font = UIFont(name: "PTSans-Italic", size: 25)
        pop_up.addSubview(place3Distance)
        let place3PickupTime = UILabel(frame: CGRect(x: 57, y: 750, width: 550, height: 80))
        place3PickupTime.text = "   Withdraw until 22:00"
        place3PickupTime.textColor = .black
        place3PickupTime.backgroundColor = .white
        place3PickupTime.font = UIFont(name: "PT Sans", size: 28)
        pop_up.addSubview(place3PickupTime)
        
        let itemDescription = UILabel(frame: CGRect(x: 700, y: 94, width: 650, height: 1000))
        itemDescription.numberOfLines = 0
        itemDescription.textColor = .white
        itemDescription.font = UIFont(name: "PT Sans", size: 37)
        itemDescription.text = self.specificItem.itemDescription
        pop_up.addSubview(itemDescription)
        
        self.view = pop_up
        
    }
    
}

class MyViewController5 : UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    let placeExamples = [Lugar(nome: "Quitandaria", hora: "19:00", dist: "a 250m"), Lugar(nome: "Bompreço", hora: "21:00", dist: "a 2.5km"), Lugar(nome: "Mercado de Zé", hora: "15:30", dist: "a 50m")]
    
    var vegetableList:[ItemStructure] = []
    
    
    override func viewDidLoad() {
        
        let appName = UILabel()
        appName.frame = CGRect(x: 42, y: 62, width: 361, height: 68)
        appName.text = "Food Bank"
        appName.textColor = .black
        let AppNameFont = UIFont (name: "PT Sans", size: 50)
        appName.font = AppNameFont
        view.addSubview(appName)
        
        let catalogTitle = UILabel()
        catalogTitle.frame = CGRect(x: 42, y: 193, width: 780, height: 88)
        catalogTitle.text = "Available food catalog"
        catalogTitle.textColor = .black
        let catalogTitleFont = UIFont (name: "PTSans-Bold", size: 65)
        catalogTitle.font = catalogTitleFont
        view.addSubview(catalogTitle)
        
        let catalogDescription = UILabel()
        catalogDescription.frame = CGRect(x: 45, y: 276, width: 316, height: 47)
        catalogDescription.text = "Category: fruits"
        catalogDescription.textColor = .black
        let descriptionFont = UIFont (name: "PT Sans", size: 35)
        catalogDescription.font = descriptionFont
        view.addSubview(catalogDescription)
        
        let mainQuestion = UILabel()
        mainQuestion.frame = CGRect(x: 401, y: 452, width: 548, height: 60)
        mainQuestion.text = "Select any option for details"
        mainQuestion.textColor = .black
        let QuestionFont = UIFont (name: "PTSans-Bold", size: 45)
        mainQuestion.font = QuestionFont
        view.addSubview(mainQuestion)
        
        vegetableList = [ItemStructure(nome: "Apple", foto: UIImage(named: "apple2.jpg"), descricao: "“An apple a day keeps the doctor away.” Apple's fibers slow digestion, decreasing overeating. They also help with diarrhea and constipation. Some studies show that apples protect against blood vessel and heart damage. They also can help lower your cholesterol, and they might protect your cells’ DNA from something called oxidative damage, which is one of the things that can lead to cancer [Webmd.com].", lugares: placeExamples), ItemStructure(nome: "Pineaplle", foto: UIImage(named: "Pineapple.jpg"), descricao: "Pineapples are tropical fruits that are rich in vitamins, enzymes and antioxidants. They may help boost the immune system, build strong bones and aid indigestion. And, despite their sweetness, pineapples are low in calories [Livescience.com].", lugares: placeExamples), ItemStructure(nome: "Mango", foto: UIImage(named: "Mangoes.jpg"), descricao: "Luscious and sweet, mango is known as the “King of Fruits.” It may protect against cancer, boosts the immune system, improve skin and hair health, ease constipation and improve blood sugar regulation [Health.com]", lugares: placeExamples), ItemStructure(nome: "Papaya", foto: UIImage(named: "Papaya.jpg"), descricao: "Originated in Central America, papayas are loaded with nutrients. They have powerful antioxidant effects and anticancer properties, as well as the capacity of improving heart health. Papayas also fight inflammation, improve digestion and protect against skin damage [Healthline.com]", lugares: placeExamples), ItemStructure(nome: "Orange", foto: UIImage(named: "Oranges.jpg"), descricao: "Every type of orange has more than 100% of your recommended daily amount of vitamin C. The vitamin C in oranges helps your body in lots of ways: it protects your cells from damage; helps your body make collagen, a protein that heals wounds; makes it easier to absorb iron; boosts your immune system, your body's defense against germs; and slows the advance of age-related macular degeneration (AMD), a leading cause of vision loss [Webmd.com]", lugares: placeExamples), ItemStructure(nome: "Pear", foto: UIImage(named: "Pear.jpg"), descricao: "A pear is a mild, sweet fruit with a fibrous center. Pears are rich in essential antioxidants, plant compounds, and dietary fiber. They pack all of these nutrients in a fat free, cholesterol free, 100 calorie package [Medicalnewstoday.com].", lugares: placeExamples), ItemStructure(nome: "Lemon", foto: UIImage(named: "Lemon.jpg"), descricao: "Lemons are an excellent source of vitamin C and flavonoids, which are antioxidants. Antioxidants help remove free radicals that can damage cells from the body. They also lower stroke risk, decrease blood pressure and prevent cancer [Medicalnewstoday.com].", lugares: placeExamples), ItemStructure(nome: "Banana", foto: UIImage(named: "banana.jpg"), descricao: "Bananas are known to reduce swelling, protect against developing Type 2 diabetes, aid in weight loss, strengthen the nervous system and help with production of white blood cells, all due to the high level of vitamin B6 that bananas contain [Livescience.com]", lugares: placeExamples), ItemStructure(nome: "Grapes", foto: UIImage(named: "Grapes.jpg"), descricao: "The nutrients in grapes may help protect against cancer, eye problems, cardiovascular disease, and other health conditions. They are a good source of fiber, potassium, and a range of vitamins and other minerals. Grapes are suitable for people with diabetes, as long as they are accounted for in the diet plan.", lugares: placeExamples)]
        
        
        view.backgroundColor = .white
        
        let myLayout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        myLayout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        myLayout.itemSize = CGSize(width: 337.7, height: 91.67)
        myLayout.minimumLineSpacing = 50
        
        
        let myCollectionView = UICollectionView(frame: CGRect(x: 86, y: 552, width: 1193, height: 372), collectionViewLayout: myLayout)
        
        myCollectionView.register(CatalogCell.self, forCellWithReuseIdentifier: "id")
        myCollectionView.backgroundColor = .white
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
        
        view.addSubview(myCollectionView)
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return vegetableList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let myCell = collectionView.dequeueReusableCell(withReuseIdentifier: "id", for: indexPath) as? CatalogCell
        
        myCell?.illustration.image = vegetableList[indexPath.item].itemPhoto
        myCell?.title.text = vegetableList[indexPath.item].itemName
        return myCell!
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let mvc4 = MyViewController4(vegetal: vegetableList[indexPath.item])
        show(mvc4, sender: nil)
        
    }
    
}

class MyViewController7 : UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    let placeExample = [Lugar(nome: "Quitandaria", hora: "19:00", dist: "a 250m"), Lugar(nome: "Bompreço", hora: "21:00", dist: "a 2.5km"), Lugar(nome: "Mercado de Zé", hora: "15:30", dist: "a 50m")]
    
    var vegetableList:[ItemStructure] = []
    
    
    override func viewDidLoad() {
        
        let appName = UILabel()
        appName.frame = CGRect(x: 42, y: 62, width: 361, height: 68)
        appName.text = "Food Bank"
        appName.textColor = .black
        let AppNameFont = UIFont (name: "PT Sans", size: 50)
        appName.font = AppNameFont
        view.addSubview(appName)
        
        let catalogTitle = UILabel()
        catalogTitle.frame = CGRect(x: 42, y: 193, width: 780, height: 88)
        catalogTitle.text = "Available food catalog"
        catalogTitle.textColor = .black
        let catalogTitleFont = UIFont (name: "PTSans-Bold", size: 65)
        catalogTitle.font = catalogTitleFont
        view.addSubview(catalogTitle)
        
        let catalogDescription = UILabel()
        catalogDescription.frame = CGRect(x: 45, y: 276, width: 316, height: 47)
        catalogDescription.text = "Category: fruits"
        catalogDescription.textColor = .black
        let catalogDescriptionFont = UIFont (name: "PT Sans", size: 35)
        catalogDescription.font = catalogDescriptionFont
        view.addSubview(catalogDescription)
        
        let mainQuestion = UILabel()
        mainQuestion.frame = CGRect(x: 401, y: 452, width: 548, height: 60)
        mainQuestion.text = "Select any option for details"
        mainQuestion.textColor = .black
        let QuestionFont = UIFont (name: "PTSans-Bold", size: 45)
        mainQuestion.font = QuestionFont
        view.addSubview(mainQuestion)
        
        vegetableList = [ItemStructure(nome: "Yogurt", foto: UIImage(named: "yogurt.jpg"), descricao: "Yogurt is made by fermenting milk wth a yogurt culture. Health benefits can include promoting bone health and aiding digestion. Some yogurts contain active, living bacteria known as probiotics, which can help keep the intestines healthy. Yogurt products that go through heat treatment have no active bacteria, reducing the health benefits. Yogurt-covered raisins are an example [Medicalnewstoday.com].", lugares: placeExample), ItemStructure(nome: "Eggs", foto: UIImage(named: "Eggs.jpg"), descricao: "Eggs are a very good source of inexpensive, high-quality protein. More than half the protein of an egg is found in the egg white, which also includes vitamin B2 and lower amounts of fat than the yolk. Eggs are rich sources of selenium, vitamin D, B6, B12 and minerals such as zinc, iron and copper [BBCgoodfood.com].", lugares: placeExample), ItemStructure(nome: "Meat", foto: UIImage(named: "Meat.jpg"), descricao: "Meat is a rich source of high-quality protein and various vitamins and minerals. As such, it can be an excellent component of a healthy diet. It helps maintaining muscle mass, improving exercise performance and preventing anemia [Healthline.com]", lugares: placeExample), ItemStructure(nome: "Salmon", foto: UIImage(named: "Salmon.jpg"), descricao: "The vitamin B12 in salmon keeps blood and nerve cells humming and helps you make DNA. But for your health, the true beauty of salmon is its wealth of omega-3 fatty acids. They can lower the chance that you have cardiovascular diseases, cancer and dementia [Webmd.com].", lugares: placeExample), ItemStructure(nome: "Cheese", foto: UIImage(named: "cheese.jpg"), descricao: "Cheese is a good source of calcium, a key nutrient for healthy bones and teeth, blood clotting, wound healing, and maintaining normal blood pressure. It improves bone and dental health, and regulates blood pressure [Medicalnewstoday.com]", lugares: placeExample), ItemStructure(nome: "Shrimp", foto: UIImage(named: "shrimp.jpg"), descricao: "Shrimp may have a variety of health benefits. It is high in several vitamins and minerals, and is a rich source of protein. Eating shrimp may also promote heart and brain health due to its content of omega-3 fatty acids and the antioxidant astaxanthin (6, 11, 12, 13) [Healthline.com]", lugares: placeExample), ItemStructure(nome: "Pork", foto: UIImage(named: "pork.jpg"), descricao: "Pork is an excellent source of protein and provides several important vitamins and minerals. A 3-ounce serving of pork is an “excellent” source of thiamin, selenium, protein, niacin, vitamin B-6 and phosphorus, and a good source of zinc, riboflavin and potassium [Pork.org].", lugares: placeExample), ItemStructure(nome: "Chicken", foto: UIImage(named: "Chicken.jpg"), descricao: "A chicken breast is a great source of quality protein for a modest number of calories and a small amount of fat. More important, it has especially little saturated fat, the type that’s linked with higher cholesterol levels and heart disease [Everydayhealth.com].", lugares: placeExample), ItemStructure(nome: "Jerked beef", foto: UIImage(named: "jerky.jpg"), descricao: "Beef jerky is a good source of protein and high in many vitamins and minerals, including zinc, iron, vitamin B12, phosphorus, and folate. It also has a long shelf life and is portable, making it a great on-the-go option [Healthline.com].", lugares: placeExample)]
        
        
        view.backgroundColor = .white
        
        let myLayout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        myLayout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        myLayout.itemSize = CGSize(width: 337.7, height: 91.67)
        myLayout.minimumLineSpacing = 50
        
        
        let myCollectionView = UICollectionView(frame: CGRect(x: 86, y: 552, width: 1193, height: 372), collectionViewLayout: myLayout)
        
        myCollectionView.register(CatalogCell.self, forCellWithReuseIdentifier: "id")
        myCollectionView.backgroundColor = .white
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
        
        view.addSubview(myCollectionView)
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return vegetableList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let myCell = collectionView.dequeueReusableCell(withReuseIdentifier: "id", for: indexPath) as? CatalogCell
        
        myCell?.illustration.image = vegetableList[indexPath.item].itemPhoto
        myCell?.title.text = vegetableList[indexPath.item].itemName
        return myCell!
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let mvc4 = MyViewController4(vegetal: vegetableList[indexPath.item])
        show(mvc4, sender: nil)
        
    }

}

let mnc = UINavigationController(screenType: .ipadPro12_9, isPortrait: false)
mnc.pushViewController(MyViewController0(), animated: true)
PlaygroundPage.current.liveView = mnc.scaleToFit()
