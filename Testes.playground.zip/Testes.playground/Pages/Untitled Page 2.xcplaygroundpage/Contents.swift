import UIKit
import PlaygroundSupport

public class Cachorro {
    public var raca: String
    public var imagemSilhueta: String
    
    
    public init(raca: String, imagemSilhueta: String) {
        self.raca = raca
        self.imagemSilhueta = imagemSilhueta
        
    }
}

class ExemploDeViewController: UIViewController, UICollectionViewDataSource {
    
    var minhaCollectionView: UICollectionView!
    
    override func loadView() {
        
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 500, height: 500))
        view.backgroundColor = .green
        
        let layoutDeExemplo: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layoutDeExemplo.sectionInset = UIEdgeInsets(top: 32, left: 20, bottom: 20, right: 20)
        layoutDeExemplo.itemSize = CGSize(width: 60, height: 65)
        
        minhaCollectionView = UICollectionView(frame: CGRect(x: 0, y: 30, width: 375, height: 607), collectionViewLayout: layoutDeExemplo)
        minhaCollectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "id")
        minhaCollectionView.backgroundColor = UIColor.white
        minhaCollectionView.dataSource = self
        
        view.addSubview(minhaCollectionView)
        
        self.view = view
    }
    
    var cachorros = [Cachorro(raca: "Bulldog", imagemSilhueta: "bulldog_silhueta.png"),
                     Cachorro(raca: "Chihuahua", imagemSilhueta: "chihuahua_silhueta.png"),
                     Cachorro(raca: "Dachshund",imagemSilhueta: "dachshund_silhueta.png"),
                     Cachorro(raca: "Golden Retriever",imagemSilhueta: "golden_silhueta.png"),
                     Cachorro(raca: "Greyhound", imagemSilhueta: "greyhound_silhueta.png"),
                     Cachorro(raca: "Maltês", imagemSilhueta: "maltes_silhueta.png"),
                     Cachorro(raca: "Pastor Alemão", imagemSilhueta: "pastor_silhueta.png"),
                     Cachorro(raca: "Samoieda", imagemSilhueta: "samoieda_silhueta.png")]
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cachorros.count
       }
       
       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           let minhaCelula = collectionView.dequeueReusableCell(withReuseIdentifier: "id", for: indexPath)
           
           minhaCelula.backgroundView = UIImageView(image: UIImage(named: cachorros[indexPath.row].imagemSilhueta))
           
           return minhaCelula
       }
    
}

let evc = ExemploDeViewController()
PlaygroundPage.current.liveView = evc

/* */
